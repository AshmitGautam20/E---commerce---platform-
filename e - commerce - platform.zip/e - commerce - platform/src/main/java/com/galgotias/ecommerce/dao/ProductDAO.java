package com.galgotias.ecommerce.dao;

import com.galgotias.ecommerce.db.DBManager;
import com.galgotias.ecommerce.model.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {

    public ProductDAO() {
        // ensure table exists
        try (Connection conn = DBManager.getConnection();
             Statement st = conn.createStatement()) {
            st.executeUpdate("""CREATE TABLE IF NOT EXISTS product (
                id INT PRIMARY KEY,
                name VARCHAR(255),
                category VARCHAR(100),
                price DOUBLE,
                stock INT
            )""");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void insert(Product p) throws SQLException {
        String sql = "MERGE INTO product KEY(id) VALUES (?,?,?,?,?)";
        try (Connection conn = DBManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, p.getId());
            ps.setString(2, p.getName());
            ps.setString(3, p.getCategory());
            ps.setDouble(4, p.getPrice());
            ps.setInt(5, p.getStock());
            ps.executeUpdate();
        }
    }

    public Product findById(int id) throws SQLException {
        String sql = "SELECT * FROM product WHERE id = ?";
        try (Connection conn = DBManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Product(rs.getInt("id"), rs.getString("name"),
                            rs.getString("category"), rs.getDouble("price"), rs.getInt("stock"));
                }
            }
        }
        return null;
    }

    public List<Product> listAll() throws SQLException {
        String sql = "SELECT * FROM product";
        List<Product> out = new ArrayList<>();
        try (Connection conn = DBManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                out.add(new Product(rs.getInt("id"), rs.getString("name"),
                        rs.getString("category"), rs.getDouble("price"), rs.getInt("stock")));
            }
        }
        return out;
    }

    public void updateStock(int id, int delta) throws SQLException {
        String sql = "UPDATE product SET stock = stock + ? WHERE id = ?";
        try (Connection conn = DBManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, delta);
            ps.setInt(2, id);
            ps.executeUpdate();
        }
    }
}

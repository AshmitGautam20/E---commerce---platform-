# E-Commerce Platform (Review 1 + Review 2)

## Overview
This is a complete Java-based E-Commerce platform developed for academic submission.
It fulfills **Review 1 and Review 2** requirements using Core Java, JDBC, Servlets, and JSP.

## Technologies
- Java
- JDBC
- Servlets
- JSP
- Maven
- Apache Tomcat

## Review 1
- OOP concepts
- Collections & Generics
- JDBC CRUD operations

## Review 2
- Servlet lifecycle
- JSP pages
- Form handling
- Session management

## How to Run
1. Import project into Eclipse/IntelliJ
2. Configure Apache Tomcat
3. Run on server

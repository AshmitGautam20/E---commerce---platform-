
package com.galgotias.ecommerce.dao;

import java.util.*;
import com.galgotias.ecommerce.model.Product;

public class ProductDAO {
    public List<Product> getAllProducts() {
        List<Product> list = new ArrayList<>();
        list.add(new Product(1, "Laptop", 50000));
        list.add(new Product(2, "Mobile", 20000));
        return list;
    }
}

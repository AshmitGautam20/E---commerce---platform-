
package com.galgotias.ecommerce.servlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import com.galgotias.ecommerce.dao.ProductDAO;

public class ProductServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        ProductDAO dao = new ProductDAO();
        req.setAttribute("products", dao.getAllProducts());
        req.getRequestDispatcher("products.jsp").forward(req, res);
    }
}

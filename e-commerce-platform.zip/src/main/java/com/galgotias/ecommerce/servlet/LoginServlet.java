
package com.galgotias.ecommerce.servlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        String user = req.getParameter("username");
        HttpSession session = req.getSession();
        session.setAttribute("user", user);
        res.sendRedirect("products");
    }
}

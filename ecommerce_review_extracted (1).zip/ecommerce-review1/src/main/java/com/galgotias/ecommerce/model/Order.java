package com.galgotias.ecommerce.model;

import java.util.Map;
import java.util.HashMap;

public class Order {
    private int id;
    private int userId;
    private Map<Integer,Integer> items = new HashMap<>(); // productId -> quantity
    private double total;

    public Order() {}

    public Order(int id, int userId) {
        this.id = id;
        this.userId = userId;
    }

    public void addItem(int productId, int qty) {
        items.put(productId, items.getOrDefault(productId, 0) + qty);
    }

    public Map<Integer,Integer> getItems() { return items; }

    public int getId() { return id; }
    public int getUserId() { return userId; }

    public void setTotal(double t) { this.total = t; }
    public double getTotal() { return total; }

    @Override
    public String toString() {
        return "Order{id=" + id + ", userId=" + userId + ", items=" + items + ", total=" + total + "}";
    }
}

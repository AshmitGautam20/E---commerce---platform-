package com.galgotias.ecommerce.service;

import com.galgotias.ecommerce.dao.ProductDAO;
import com.galgotias.ecommerce.model.Order;
import com.galgotias.ecommerce.model.Product;

import java.sql.SQLException;
import java.util.List;

public class OrderProcessor implements Runnable {
    private Order order;
    private ProductDAO productDAO;

    public OrderProcessor(Order order, ProductDAO productDAO) {
        this.order = order;
        this.productDAO = productDAO;
    }

    @Override
    public void run() {
        try {
            double total = 0.0;
            for (var e : order.getItems().entrySet()) {
                int pid = e.getKey();
                int qty = e.getValue();
                Product p = productDAO.findById(pid);
                if (p != null && p.getStock() >= qty) {
                    productDAO.updateStock(pid, -qty);
                    total += p.getPrice() * qty;
                } else {
                    System.out.println("Order " + order.getId() + " failed for product " + pid + " (insufficient stock)");
                }
            }
            order.setTotal(total);
            System.out.println("Order processed: " + order);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}

package com.galgotias.ecommerce;

import com.galgotias.ecommerce.dao.ProductDAO;
import com.galgotias.ecommerce.model.Order;
import com.galgotias.ecommerce.model.Product;
import com.galgotias.ecommerce.service.OrderProcessor;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {
    public static void main(String[] args) throws Exception {
        ProductDAO dao = new ProductDAO();

        // seed products
        dao.insert(new Product(1, "T-Shirt", "Clothing", 399.0, 50));
        dao.insert(new Product(2, "Sneakers", "Footwear", 2499.0, 20));
        dao.insert(new Product(3, "Headphones", "Electronics", 1299.0, 15));

        System.out.println("Products in catalog:");
        for (Product p : dao.listAll()) {
            System.out.println(p);
        }

        // create two orders and process concurrently to demonstrate multithreading & synchronization via DB transactions
        Order o1 = new Order(1001, 501);
        o1.addItem(1, 2);
        o1.addItem(3, 1);

        Order o2 = new Order(1002, 502);
        o2.addItem(1, 49); // large quantity to show potential contention

        ExecutorService ex = Executors.newFixedThreadPool(2);
        ex.submit(new OrderProcessor(o1, dao));
        ex.submit(new OrderProcessor(o2, dao));

        ex.shutdown();
        while (!ex.isTerminated()) {
            Thread.sleep(200);
        }

        System.out.println("Final product stocks:");
        for (Product p : dao.listAll()) {
            System.out.println(p);
        }
    }
}
